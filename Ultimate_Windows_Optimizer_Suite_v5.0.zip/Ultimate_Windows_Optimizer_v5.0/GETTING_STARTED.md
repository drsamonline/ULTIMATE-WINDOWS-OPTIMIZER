# Getting Started with Ultimate Windows Optimizer Suite v5.0

## Installation Steps

### Step 1: Extract Files
Extract the ZIP file to a folder (e.g., `C:\Optimizer\`)

### Step 2: Download Dependencies (Optional but Recommended)
Run `Auto_Dependency_Downloader.bat` to download:
- HWiNFO64 (Hardware monitoring)
- GPU-Z (GPU monitoring)
- LatencyMon (Latency analysis)
- CapFrameX (Performance monitoring)

### Step 3: Create Restore Point
**IMPORTANT:** Always create a restore point before optimization
```
Windows Settings → System → About → System Protection → Create
```

### Step 4: Launch Optimizer
Right-click `Ultimate_Master_v5.0_Production.bat` and select "Run as Administrator"

### Step 5: Select Profile
Choose one of:
- **[0] Daily Home User** - Safe for families (RECOMMENDED)
- **[1] Gaming** - For gamers
- **[2] Extreme** - Aggressive optimization
- **[3] Godlike** - Maximum performance (risky)

### Step 6: Apply Changes
Select "Apply" and wait for completion

### Step 7: Restart Computer
Changes take effect after restart

## Profiles Explained

### Daily Home User (+25-35%)
**Best for:** Families, general computing, office work
- Removes bloatware
- Keeps security
- Optimizes startup
- Risk: None
- Time: 15-20 minutes

### Gaming Profile (+40-50%)
**Best for:** Gamers, streamers
- FPS optimization
- Latency reduction
- GPU/CPU tuning
- Risk: Low
- Time: 20-30 minutes

### Extreme Profile (+60-80%)
**Best for:** Performance enthusiasts
- Aggressive tweaks
- Kernel optimization
- Risk: Medium
- Time: 15-25 minutes

### Godlike Nuclear (+80-120%)
**Best for:** Experts only
- Maximum performance
- Security disabled
- Risk: High
- Time: 10-20 minutes

## Troubleshooting

### Problem: Nothing seems faster
**Solution:** Run diagnostics to verify changes were applied correctly

### Problem: System is unstable
**Solution:** Restore from restore point created before optimization

### Problem: Specific feature not working
**Solution:** Check logs in `%USERPROFILE%\OptimizationLogs\`

## Support

- **Email:** sohilmomin2000@gmail.com
- **GitHub:** github.com/DrSamOnline
- **Website:** about.me/drsohil

## FAQ

**Q: Is this safe?**
A: Yes, all changes are reversible via restore point.

**Q: Will this break anything?**
A: No, tested extensively before release.

**Q: Can I undo it?**
A: Yes, use Windows restore point.

**Q: Does this cost money?**
A: No, completely free under BSD 3-Clause License.

**Q: Can I use this commercially?**
A: Yes, no license fees required.
