# Support & Contact Information

## Contact Information

### Primary Contact
- **Email:** sohilmomin2000@gmail.com
- **GitHub:** @DrSamOnline
- **Website:** about.me/drsohil

### GitHub Repository
- **URL:** github.com/DrSamOnline/ultimate-windows-optimizer
- **Issues:** github.com/DrSamOnline/ultimate-windows-optimizer/issues
- **Discussions:** github.com/DrSamOnline/ultimate-windows-optimizer/discussions

## Getting Help

### For Bug Reports
Email with:
1. Windows version and build
2. System specs (CPU, GPU, RAM)
3. Profile used
4. Error message
5. Steps to reproduce
6. Log files (if available)

### For Feature Requests
Email with:
1. Feature description
2. Use case
3. Expected benefit
4. Implementation suggestions

### For General Questions
Check FAQ.md first, then email if not answered

## Community

### GitHub
- Submit issues for bugs
- Use discussions for Q&A
- Fork for contributions
- Star to show support

### Contributing
Contributions welcome! Please:
1. Fork repository
2. Create feature branch
3. Make improvements
4. Submit pull request
5. Include attribution

## Documentation

### Included Files
- README.md - Overview
- GETTING_STARTED.md - Quick start
- PROFILES_EXPLAINED.md - Profile details
- TECHNICAL_SPECS.md - Technical info
- FAQ.md - Common questions
- SUPPORT.md - This file

### Documentation Formats
- Markdown (.md)
- Batch scripts (.bat)
- Text files (.txt)

## License

### Open Source License
- Type: BSD 3-Clause License
- Free to use
- Attribution required
- Commercial use allowed
- No license fees

### License File
See LICENSE file in repository

## Reporting Issues

### Issue Template
```
Title: Clear, concise title
Description: Detailed problem description
Environment: 
  - Windows: [version]
  - System: [specs]
  - Profile: [used]
Steps: Steps to reproduce
Expected: Expected behavior
Actual: Actual behavior
Logs: Attached error logs
```

## Response Times

### Support Response
- **Bugs:** 24-48 hours
- **Features:** 48-72 hours
- **Questions:** 24-48 hours
- **Issues:** Best effort

## Known Issues

### Current Status
- No critical issues known
- Some edge cases with old hardware
- Rare compatibility issues possible

### Workarounds
See TROUBLESHOOTING.md for solutions

## Updates & News

### Latest News
Follow @DrSamOnline on GitHub for updates

### Version History
See CHANGELOG.md for release notes

### Roadmap
- v5.1: GUI interface
- v5.2: Real-time dashboard
- v5.3: AI auto-profiling
- v6.0: Complete rewrite
