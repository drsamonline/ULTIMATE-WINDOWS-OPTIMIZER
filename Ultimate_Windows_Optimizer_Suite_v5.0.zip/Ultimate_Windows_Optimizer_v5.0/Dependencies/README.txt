DEPENDENCIES FOLDER

This folder contains optional utilities that enhance optimization capabilities.

Recommended downloads:
1. HWiNFO64 - Hardware monitoring (hwinfo.com)
2. GPU-Z - GPU information (techpowerup.com)
3. LatencyMon - DPC latency (resplendence.com)
4. CapFrameX - Performance monitoring (github.com/CaptureFrameX)

Use Auto_Dependency_Downloader.bat to download these automatically.

---

Created by: Coding For Fun (@DrSamOnline)
License: BSD 3-Clause License
Email: sohilmomin2000@gmail.com
Website: about.me/drsohil
