DEPENDENCIES FOLDER

This folder contains optional monitoring utilities.

OPTIONAL UTILITIES:
1. HWiNFO64.exe - Hardware monitoring
2. GPU-Z.exe - GPU information

These utilities are OPTIONAL - the optimizer works without them.

AUTO-DOWNLOAD:
Run Auto_Dependency_Downloader.bat to download these automatically.

MANUAL DOWNLOAD:
If auto-download fails, see MANUAL_DOWNLOAD_GUIDE.txt created by the downloader.

Created by: Coding For Fun (@DrSamOnline)
License: BSD 3-Clause
