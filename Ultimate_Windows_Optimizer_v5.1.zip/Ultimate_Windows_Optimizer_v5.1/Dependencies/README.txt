DEPENDENCIES FOLDER

Optional monitoring utilities downloaded by the downloader script.

Utilities:
- HWiNFO64.exe (Hardware monitoring)
- GPU-Z.exe (GPU information)

Download manually from:
- HWiNFO64: https://www.hwinfo.com/
- GPU-Z: https://www.techpowerup.com/gpu-z/

Created by: Coding For Fun (@DrSamOnline)
