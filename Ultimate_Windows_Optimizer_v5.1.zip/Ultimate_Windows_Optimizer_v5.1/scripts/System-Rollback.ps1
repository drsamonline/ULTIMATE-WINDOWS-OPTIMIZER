if (-not ([Security.Principal.WindowsPrincipal]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 1 }
Write-Host "SYSTEM ROLLBACK" -ForegroundColor Red
$confirm = Read-Host "Proceed (Y/N)"
if ($confirm -ne "Y") { exit 0 }
Start-Process "rstrui.exe" -Wait
Write-Host "[SUCCESS]" -ForegroundColor Green
pause
