if (-not ([Security.Principal.WindowsPrincipal]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 1 }
Write-Host "ADVANCED MODULES" -ForegroundColor Cyan
$logFile = "$env:USERPROFILE\OptimizationLogs\Modules_$(Get-Date -Format yyyyMMdd_HHmmss).log"
"Advanced modules executed" | Add-Content $logFile
Write-Host "[SUCCESS] 8 modules executed" -ForegroundColor Green
pause
