if (-not ([Security.Principal.WindowsPrincipal]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 1 }
Write-Host "COMPATIBILITY CHECK" -ForegroundColor Cyan
$osVersion = (Get-WmiObject Win32_OperatingSystem).Version
if ($osVersion -like "10.0*") { Write-Host "[OK] Windows 10/11 Compatible" -ForegroundColor Green }
Write-Host "[SUCCESS]" -ForegroundColor Green
pause
