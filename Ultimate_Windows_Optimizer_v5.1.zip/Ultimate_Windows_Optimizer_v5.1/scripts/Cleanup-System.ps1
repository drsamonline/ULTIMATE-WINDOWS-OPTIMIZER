if (-not ([Security.Principal.WindowsPrincipal]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 1 }
Write-Host "SYSTEM CLEANUP" -ForegroundColor Cyan
Remove-Item "$env:TEMP\*" -Force -Recurse -ErrorAction SilentlyContinue
Write-Host "[SUCCESS] Cleanup complete" -ForegroundColor Green
pause
