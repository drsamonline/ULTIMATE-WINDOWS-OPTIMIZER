if (-not ([Security.Principal.WindowsPrincipal]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 1 }
Write-Host "PERFORMANCE METRICS" -ForegroundColor Cyan
$mem = Get-WmiObject Win32_OperatingSystem
$used = [math]::Round(($mem.TotalVisibleMemorySize - $mem.FreePhysicalMemory) / 1MB, 2)
Write-Host "RAM: $used MB" -ForegroundColor Yellow
Write-Host "[SUCCESS]" -ForegroundColor Green
pause
