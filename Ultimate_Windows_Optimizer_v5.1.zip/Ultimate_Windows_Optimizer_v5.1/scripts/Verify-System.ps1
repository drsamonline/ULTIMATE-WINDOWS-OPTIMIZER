if (-not ([Security.Principal.WindowsPrincipal]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 1 }
Write-Host "OPTIMIZATION VERIFICATION" -ForegroundColor Cyan
$svc = Get-Service DiagTrack -ErrorAction SilentlyContinue
if ($svc -and $svc.Status -eq "Stopped") { Write-Host "[OK] DiagTrack stopped" -ForegroundColor Green }
Write-Host "[SUCCESS]" -ForegroundColor Green
pause
