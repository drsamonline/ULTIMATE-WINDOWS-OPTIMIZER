if (-not ([Security.Principal.WindowsPrincipal]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 1 }
Write-Host "HARDWARE INFORMATION" -ForegroundColor Cyan
Get-WmiObject Win32_Processor | Select-Object Name, Cores, Threads
Get-WmiObject Win32_VideoController | Select-Object Name
Write-Host "[SUCCESS]" -ForegroundColor Green
pause
