if (-not ([Security.Principal.WindowsPrincipal]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 1 }
Write-Host "UNDO ALL CHANGES" -ForegroundColor Red
$confirm = Read-Host "Revert everything (Y/N)"
if ($confirm -ne "Y") { exit 0 }
Get-Service DiagTrack -ErrorAction SilentlyContinue | Start-Service -ErrorAction SilentlyContinue
Write-Host "[SUCCESS] Reverted" -ForegroundColor Green
pause
